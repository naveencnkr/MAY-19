var input="abdullah khan";
var str=input.split(" ");
var output=str[1]+" "+str[0];
console.log(output);